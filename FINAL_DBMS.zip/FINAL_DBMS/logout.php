<?php

session_start();
session_destroy();

echo "THANK YOU";

header('location:homepage.html');


 ?>