<?php 

session_start();

$con=mysqli_connect('localhost','root');
if($con){
	echo "connection successful";
}
else{
	echo "no connection";
}
mysqli_select_db($con,'signupdb');
$name=$_POST['uname'];
$pass=$_POST['psw'];

$q="select * from signin where username ='$name' && password ='$pass'";

$result = mysqli_query($con,$q);

$num = mysqli_num_rows($result);

if($num==1){
	header('location:Registration.html');
}else{
	header('location:login.html');
}

 ?>